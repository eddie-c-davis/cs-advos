//
// Created by edavis on 10/2/17.
//

#ifndef GAUSSSEIDEL_CSRMATRIX_H
#define GAUSSSEIDEL_CSRMATRIX_H

#include <cstdio>
#include <iostream>

#include "Matrix.hpp"
#include "Vector.hpp"

using namespace std;

class CSRMatrix : public Matrix {
public:
    CSRMatrix(int nRows = 0, int nCols = 0, double defValue = 0.0) {
        init(nRows, nCols, defValue);
    }

    CSRMatrix(int nRows, int nCols, DType *values) {
        init(nRows, nCols, values);
    }

    CSRMatrix(const Matrix& matrix) {
        // Convert dense matrix to CSR...
        init(matrix.nRows(), matrix.nCols(), matrix.data());
    }

    CSRMatrix(const CSRMatrix& matrix) {
        copy(matrix);
    }

    virtual ~CSRMatrix() {
        if (_values != nullptr) {
            free(_values);
            free(_rowptr);
            free(_colidx);
        }
    }

    DType *data() {
        if (_data == nullptr) {
            // Convert this back to a dense matrix...
            allocate();
            for (int i = 0; i < _nRows; i++) {
                for (int k = _rowptr[i]; k < _rowptr[i + 1]; k++) {
                    int j = _colidx[k];
                    _data[index(i, j)] = _values[k];
                }
            }
        }

        return _data;
    }

    int *rowptr() const {
        return _rowptr;
    }

    int *colidx() const {
        return _colidx;
    }

    DType *values() const {
        return _values;
    }

    int nnz() const {
        return _nnz;
    }

    void operator=(const CSRMatrix& matrix) {
        copy(matrix);
    }

    // TODO: How to write a location that is currently zero without rebuilding entire matrix?
    //   Apparently there isn't a good way, one source I read said that a hash table based version
    //   of COO should be used to build a matrix, then convert to CSR to do math operations.
//    double& operator()(int row, int col) {
//        assert(row >= 0 && row < _nRows);
//        assert(col >= 0 && col < _nCols);
//
//        _changed = true;
//
//        return _data[row][col];
//    }

    const double operator()(int row, int col) const {
        assert(col >= 0 && col < _nCols);
        assert(row >= 0 && row < _nRows);

        double value = 0.0;     // This is a sparse matrix, so safe assumption...

        for (int i = _rowptr[row]; i < _rowptr[row + 1]; i++) {
            if (_colidx[i] == col) {
                value = _values[i];
            }
        }

        return value;
    }

    friend ostream& operator<<(ostream& out, const CSRMatrix& matrix) {
        int nnz = matrix.nnz();
        DType *val = matrix.values();
        int *col = matrix.colidx();
        int *row = matrix.rowptr();

        out << "val: [ ";
        for (int i = 0; i < nnz; i++) {
            out << val[i] << " ";
        }
        out << "]" << endl;

        out << "col: [ ";
        for (int i = 0; i < nnz; i++) {
            out << col[i] << " ";
        }
        out << "]" << endl;

        out << "row: [ ";
        for (int i = 0; i <= matrix.nRows(); i++) {
            out << row[i] << " ";
        }
        out << "]" << endl;

        return out;
    }

    CSRMatrix operator*(const DType& scalar) const {
        CSRMatrix result(*this);
        for (int i = 0; i < result.nnz(); i++) {
            result._values[i] *= scalar;
        }

        return result;
    }

    // This is where it gets interesting, this is SpMV!
    Vector operator*(const Vector& vec) const {
        //Input: Matrix mat[m][n]
        //Vector vec[n]
        //Output: out[m]
        assert(_nCols == vec.size());

        Vector out(_nRows, 0.0);
        DType *x = vec.values();
        DType *y = out.values();

        for (int i = 0; i < _nRows; i++) {
            for (int k = _rowptr[i]; k < _rowptr[i + 1]; k++) {
                y[i] += _values[k] * x[_colidx[k]];
            }
        }

        return out;
    }

    // Matrix-matrix multiplication in CSR...
    CSRMatrix operator*(const CSRMatrix& other) const {
        assert(_nCols == other.nRows());

        CSRMatrix result(_nRows, _nCols);

        // TODO: Surprisingly, I cannot find an algorithm for this, I suspect
        //   it will involve finding the max NNZ and nRows, and iterating over
        //   those somehow...
//        DType **otherData = other.data();
//        DType **resData = result.data();

        int maxNNZ = nnz();
        if (other.nnz() > maxNNZ) {
            maxNNZ = other.nnz();
        }

        int maxRows = nRows();
        if (other.nRows() > maxRows) {
            maxRows = other.nRows();
        }

        for (int i = 0; i < maxRows; i++) {
//            for (int j = 0; j < other.nCols(); j++) {
//                for (int k = 0; k < _nCols; k++) {
//                    resData[i][j] += _data[i][k] * otherData[k][j];
//                }
//            }

            // Now extrapolate from SpMV...
//            for (int k = _rowptr[i]; k < _rowptr[i + 1]; k++) {
//                y[i] += _values[k] * x[_colidx[k]];
//            }
        }

        return result;
    }

protected:
    void copy(const CSRMatrix& matrix) {
        _nnz = matrix.nnz();
        _nRows = matrix.nRows();
        _nCols = matrix.nCols();

        DType *val = matrix.values();
        int *col = matrix.colidx();
        int *row = matrix.rowptr();

        _values = (DType *) calloc(_nnz, sizeof(DType));
        _colidx = (int *) calloc(_nnz, sizeof(int));
        _rowptr = (int *) calloc(_nRows + 1, sizeof(int));

        for (int i = 0; i < _nnz; i++) {
            _values[i] = val[i];
            _colidx[i] = col[i];
        }

        for (int i = 0; i <= _nRows; i++) {
            _rowptr[i] = row[i];
        }
    }

    void init(int nRows = 0, int nCols = 0, double defValue = 0.0) {
        _nRows = nRows;
        _nCols = nCols;
        _data = nullptr;

        if (_nRows < 1 || _nCols < 1) {
            _values = nullptr;
            _rowptr = nullptr;
            _colidx = nullptr;
        } else {
            if (defValue != 0.0) {
                _nnz = _nRows * _nCols;
            } else {
                _nnz = 0;
            }

            _values = (DType *) calloc(_nnz, sizeof(DType));
            _colidx = (int *) calloc(_nnz, sizeof(int));
            _rowptr = (int *) calloc(_nRows + 1, sizeof(int));

            _changed = false;
        }
    }

    void init(int nRows, int nCols, DType *values) {
        _nRows = nRows;
        _nCols = nCols;
        _data = nullptr;

        if (_nRows < 1 || _nCols < 1) {
            _values = nullptr;
            _rowptr = nullptr;
            _colidx = nullptr;
        } else {
            _nnz = 0;
            for (int i = 0; i < _nRows; i++) {
                for (int j = 0; j < _nCols; j++) {
                    int k = index(i, j);
                    if (values[k] != 0.0) {
                        _nnz += 1;
                    }
                }
            }

            if (_nnz > 0) {
                _values = (DType *) calloc(_nnz, sizeof(DType));
                _colidx = (int *) calloc(_nnz, sizeof(int));
                _rowptr = (int *) calloc(_nRows + 1, sizeof(int));

                int k = 0;
                _rowptr[0] = 0;
                for (int i = 0; i < _nRows; i++) {
                    int m = 0;
                    for (int j = 0; j < _nCols; j++) {
                        double value = values[index(i, j)];
                        if (value != 0.0) {
                            _values[k] = value;
                            _colidx[k] = j;
                            k++;
                            m++;
                        }
                    }
                    _rowptr[i + 1] = _rowptr[i] + m;
                }
            }
        }
    }

    DType *_values;
    DType *_idiag;

    int _nnz;
    int *_rowptr;
    int *_colidx;
};

#endif //GAUSSSEIDEL_CSRMATRIX_H
