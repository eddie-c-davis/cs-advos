//
// Created by edavis on 10/2/17.
//

#ifndef GAUSSSEIDEL_DIAMATRIX_H
#define GAUSSSEIDEL_DIAMATRIX_H

#include <cstdio>
#include <iostream>

#include "Matrix.hpp"
#include "Vector.hpp"

using namespace std;

class DIAMatrix : public Matrix {
public:
    DIAMatrix(int nRows = 0, int nCols = 0, double defValue = 0.0) {
        init(nRows, nCols, defValue);
    }

    DIAMatrix(int nRows, int nCols, DType *values) {
        init(nRows, nCols, values);
    }

    DIAMatrix(const Matrix& matrix) {
        // Convert dense matrix to DIA...
        init(matrix.nRows(), matrix.nCols(), matrix.data());
    }

    DIAMatrix(const CSRMatrix& matrix) {
        // Convert CSR matrix to DIA...
        init(matrix);
    }

    DIAMatrix(const DIAMatrix& matrix) {
        copy(matrix);
    }

    virtual ~DIAMatrix() {
        if (_values != nullptr) {
            free(_values);
            free(_offsets);
        }
    }

    DType *data() {
        if (_data == nullptr) {
            // Convert this back to a dense matrix...
            allocate();
            // TODO: Implement me...
//            for (int i = 0; i < _nRows; i++) {
//                for (int k = _rowptr[i]; k < _rowptr[i + 1]; k++) {
//                    int j = _colidx[k];
//                    _data[index(i, j)] = _values[k];
//                }
//            }
        }

        return _data;
    }

    int *offsets() const {
        return _offsets;
    }

    DType *values() const {
        return _values;
    }

    int nDiags() const {
        return _nDiags;
    }

    void operator=(const DIAMatrix& matrix) {
        copy(matrix);
    }

    const double operator()(int row, int col) const {
        assert(col >= 0 && col < _nCols);
        assert(row >= 0 && row < _nRows);

        double value = 0.0;     // This is a sparse matrix, so safe assumption...

        // TODO: Implement me...
//        for (int i = _rowptr[row]; i < _rowptr[row + 1]; i++) {
//            if (_colidx[i] == col) {
//                value = _values[i];
//            }
//        }

        return value;
    }

    friend ostream& operator<<(ostream& out, const DIAMatrix& matrix) {
        int nRows = matrix.nRows();
        int nDiags = matrix.nDiags();

        DType *values = matrix.values();
        int *offsets = matrix.offsets();

        out << "values: [ ";
        for (int i = 0; i < nRows; i++) {
            int k = i * nDiags;
            for (int j = 0; j < nDiags; j++) {
                out << values[k + j] << " ";
            }
        }
        out << "]" << endl;

        out << "offsets: [ ";
        for (int i = 0; i < nDiags; i++) {
            out << offsets[i] << " ";
        }
        out << "]" << endl;

        return out;
    }

    DIAMatrix operator*(const DType& scalar) const {
        DIAMatrix result(*this);
        for (int i = 0; i < result.nRows(); i++) {
            for (int j = 0; j < result.nDiags(); j++) {
                result._values[index(i, j)] *= scalar;
            }
        }

        return result;
    }

    // This is where it gets interesting, this is SpMV!
    Vector operator*(const Vector& vec) const {
        //Input: Matrix mat[m][n]
        //Vector vec[n]
        //Output: out[m]
        assert(_nCols == vec.size());

        Vector out(_nRows, 0.0);
        DType *x = vec.values();
        DType *y = out.values();

        int shift = _nDiags / 2;
        for (int k = 0; k < _nDiags; k++) {
            for (int i = 0; i < _nRows; i++) {
//                int col_dia = k;
//                int col_dense = _offsets[k] + shift;
                y[i] += _values[i * _nDiags + k] * x[_offsets[k] + shift];
            }
        }

        return out;
    }

    // Matrix-matrix multiplication in DIA...
    DIAMatrix operator*(const DIAMatrix& other) const {
        assert(_nCols == other.nRows());

        DIAMatrix result(_nRows, _nCols);

        // TODO: Surprisingly, I cannot find an algorithm for this, I suspect
        //   it will involve finding the max NNZ and nRows, and iterating over
        //   those somehow...
//        DType **otherData = other.data();
//        DType **resData = result.data();

        int maxDiags = nDiags();
        if (other.nDiags() > maxDiags) {
            maxDiags = other.nDiags();
        }

        int maxRows = nRows();
        if (other.nRows() > maxRows) {
            maxRows = other.nRows();
        }

        for (int i = 0; i < maxRows; i++) {
//            for (int j = 0; j < other.nCols(); j++) {
//                for (int k = 0; k < _nCols; k++) {
//                    resData[i][j] += _data[i][k] * otherData[k][j];
//                }
//            }

            // Now extrapolate from SpMV...
//            for (int k = _rowptr[i]; k < _rowptr[i + 1]; k++) {
//                y[i] += _values[k] * x[_colidx[k]];
//            }
        }

        return result;
    }

protected:
    inline int index(int row, int col) const {
        return row * _nDiags + col;
    }

    void copy(const DIAMatrix& matrix) {
        _nRows = matrix.nRows();
        _nCols = matrix.nCols();
        _nDiags = matrix.nDiags();

        DType *values = matrix.values();
        int *offsets = matrix.offsets();
        int nValues = _nRows * _nDiags;

        _values = (DType *) calloc(nValues, sizeof(DType));
        _offsets = (int *) calloc(_nDiags, sizeof(int));

        for (int i = 0; i < nValues; i++) {
            _values[i] = values[i];
        }

        for (int i = 0; i < _nDiags; i++) {
            _offsets[i] = offsets[i];
        }
    }

    void init(int nRows = 0, int nCols = 0, double defValue = 0.0) {
        _nRows = nRows;
        _nCols = nCols;
        _data = nullptr;
        _nDiags = 0;

        if (_nRows < 1 || _nCols < 1) {
            _values = nullptr;
            _offsets = nullptr;
        } else {
            // TODO: Implement me... maybe?
        }
    }

    void init(int nRows, int nCols, DType *values) {
        assert(nRows > 0);
        assert(nCols > 0);

        _nRows = nRows;
        _nCols = nCols;
        _nDiags = _nRows + _nCols - 1;

        int *counts = (int *) calloc(_nDiags, sizeof(int));
        for (int i = 0; i < _nDiags; i++) {
            counts[i] = 0;
        }

        int nnzDiags = 0;
        int shift = _nDiags / 2;
        for (int i = 0; i < nRows; i++) {
            for (int j = 0; j < nCols; j++) {
                int diag = j - i + shift;
                if (values[i * nCols + j] != 0.0 && counts[diag] < 1) {
                    counts[diag] = 1;
                    nnzDiags += 1;
                }
            }
        }

        _offsets = (int *) calloc(nnzDiags, sizeof(int));

        int j = 0;
        for (int i = 0; i < _nDiags; i++) {
            if (counts[i] > 0) {
                _offsets[j] = i - shift;
                j++;
            }
        }

        free(counts);
        _nDiags = nnzDiags;

        int nValues = _nRows * _nDiags;
        _values = (DType *) calloc(nValues, sizeof(DType));

        // Default to padded value...
        for (int i = 0; i < nValues; i++) {
            _values[i] = 0.0;
        }

        shift = _nDiags / 2;
        for (int i = 0; i < _nRows; i++) {
            for (int j = 0; j < _nCols; j++) {
                int diag = shift + j - i;
                _values[i * _nDiags + diag] = values[i * _nCols + j];
            }
        }
    }

    void init(const CSRMatrix& matrix) {
        _nRows = matrix.nRows();
        _nCols = matrix.nCols();
        _nDiags = _nRows + _nCols - 1;

        int nnz = matrix.nnz();
        int *rowptr = matrix.rowptr();
        int *colidx = matrix.colidx();
        DType *values = matrix.values();

        int *counts = (int *) calloc(_nDiags, sizeof(int));
        for (int i = 0; i < _nDiags; i++) {
            counts[i] = 0;
        }

        int nnzDiags = 0;
        int shift = _nDiags / 2;

        for (int i = 0; i < _nRows; i++) {
            for (int j = rowptr[i]; j < rowptr[i + 1]; j++) {
                int diag = (colidx[j] - i) + shift;
                if (counts[diag] < 1) {
                    counts[diag] = 1;
                    nnzDiags += 1;
                }
            }
        }

        _offsets = (int *) calloc(nnzDiags, sizeof(int));

        int j = 0;
        for (int i = 0; i < _nDiags; i++) {
            if (counts[i] > 0) {
                _offsets[j] = i - shift;
                j++;
            }
        }

        free(counts);
        _nDiags = nnzDiags;

        int nValues = _nRows * _nDiags;
        _values = (DType *) calloc(nValues, sizeof(DType));

        // Default to padded value...
        for (int i = 0; i < nValues; i++) {
            _values[i] = 0.0;
        }

        shift = _nDiags / 2;
        for (int i = 0; i < _nRows; i++) {
            for (int j = rowptr[i]; j < rowptr[i + 1]; j++) {
                int diag = shift + colidx[j] - i;
                _values[i * _nDiags + diag] = values[j];
            }
        }
    }

    DType *_values;

    int _nDiags;
    int *_offsets;
};

#endif //GAUSSSEIDEL_DIAMATRIX_H
