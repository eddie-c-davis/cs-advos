--===========================
-- Script for CUDA-CHiLL:
--===========================
init("main.cpp", "spmv", 0)
dofile("cudaize.lua")

make_dense(0,2,"k")

known("lb",0)
known("ub",999999)
known("n", 1000000)
skew({0},2,{-1,1})
permute(0,{"k","i","j"})
shift_to(0,1,0)
known({"index_", "index__"}, {-1,1}, -1, 0)
compact(0,{1},{"a_prime"}, 0, {"a"})
print_code(1)

permute(0,{"i","k"})
print("\nthe num of statements:%d\n",new_num_stmts)
N = 1000000
Ti = 256
tile_by_index(0,{"i"},{Ti},{l1_control="ii"},{"ii","i","k"})
tile_by_index(0,{"k"},{Ti},{l1_control="kk"},{"ii","i","kk","k"})
normalize_index(0,"k")
cudaize(0,"spmv_diag_GPU",{x=N,y=N},{block={"ii"}, thread={"i"}}, {"chill_count_1", "a_prime", "_P_DATA1"})
copy_to_shared(0,"k","_P_DATA1",-16)
--print_code(5)
copy_to_registers(0, "kk", "y”);
