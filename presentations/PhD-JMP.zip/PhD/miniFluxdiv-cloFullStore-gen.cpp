#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/time.h>
#include <ctype.h>
#include <omp.h>

#include "../common/Configuration.h"
#include "../common/Measurements.h"
#include "util.h"

/****************************************************************************
 * This file is meant to explain the mini-application as it was developed.
 * Please see the comments below for a full explaination.
 *
 ****************************************************************************
 *
 * Modified on 08 July 2016 by Sarah Willer
 * Changes to param options:
 *  >> replaced call to MFD_Configuration constructor with call to
 *     Configuration constructor
 *  >> "help" 'h' and "verify" 'v' are still included in the Configuration
 *     constructor. The other common command line options are listed in
 *     Configuration.txt
 *  >> nGhost set to NGHOST defined in Configuration.h
 *  >> numComp set to NCOMP defined in Configuration.h
 *  >> added explicit addParam calls for numCell and numBox
 *
****************************************************************************/

Real** mini_flux_div_lc(Real** old_boxes,Real** new_boxes,
                        Configuration& config, Measurements& measurements);

using namespace std;

int main(int argc, char **argv) {

    int verify=0;
    int flux_totalSize;
    int idx,iz,iy,ix;
    int index;
    int v, c;
    Real **result_data;
    struct timeval tv1,tv2;

    // Constructor for parsing the command line arguments
    Configuration config;

    /**************************************************************************
    **  Parameter options. Help and verify are constructor defaults.  *********
    **************************************************************************/
    config.addParamInt("numCell", 'C' , 128 ,
                       "--numCell, the number of cells in a single dimension of a"
                       " single box");

    config.addParamInt("numBox",'B', 32 ,
                       "--numBox, the number of independent boxes to process");

    config.addParamInt("num_threads",'p',1,
                       "-p <num_threads>, number of cores");

    //Constructor for Measurements
    Measurements measurements;

    config.parse(argc,argv);

    int numCell= config.getInt("numCell");
    int numBox= config.getInt("numBox");
    int nGhost = NGHOST;
    int numComp= NCOMP;

    // t = config.getInt("tests");
    // v = config.getInt("verify");

    if(numCell < 0) {
        fprintf(stderr,"The value of numCell has to be a positive number %d\n",
                numCell);
        exit(-1);
    }

    if(numBox < 0) {
        fprintf(stderr,"The value of numBox has to be a positive number %d\n",
                numBox);
        exit(-1);
    }

    setNumThreads(config.getInt("num_threads"));

    Real **old_boxes;
    Real **new_boxes;

    //allocate call
    allocateAndInitialize(&old_boxes,&new_boxes,config);

    // Calling Benchmark Function
    mini_flux_div_lc(old_boxes,new_boxes,config,measurements);

    //Calling Verification from Util
    if(config.getBool("v")) {
        if (verifyResult(new_boxes, config)) {
            measurements.setField("verification", "SUCCESS");
        } else {
            measurements.setField("verification", "FAILURE");
        }
    }

    //get results from measurements
    string result = measurements.toLDAPString();
    string config_in = config.toLDAPString();
    cout << config_in << result << endl;

    return 0;
}

/*******************************************************************************
 * The following function is meant to be explainatory code. This implementation
 * is meant purely to explain the control flow and algorithm. Other
 * implementations include optimizations that sometimes obfuscate the
 * algorithm.
 *
 *  Processing the boxes means that we will be reading the data from
 *  old_boxes and writing them to new_boxes
 *  The following are the equations for this calculation
 *
 *  There are 5 components: p, e, u, v, w (density, energy, velocity (3D))
 *  Each of these components is represented as a 3D array (initialized
 *  above).
 * p_{t+1}(z,y,x) = h(p_t,z,y,x) + h'(p_t,z,y,x) + h"(p_t,z,y,x)
 * e_{t+1}(z,y,x) = h(e_t,z,y,x) + h'(e_t,z,y,x) + h"(e_t,z,y,x)
 * u_{t+1}(z,y,x) = h(u_t,z,y,x) + h'(u_t,z,y,x) + h"(u_t,z,y,x)
 * v_{t+1}(z,y,x) = h(v_t,z,y,x) + h'(v_t,z,y,x) + h"(v_t,z,y,x)
 * w_{t+1}(z,y,x) = h(w_t,z,y,x) + h'(w_t,z,y,x) + h"(w_t,z,y,x)
 *
 *  Computing face-centered, flux values based on cell-centered values
 *  g(component,z,y,x) is a stencil operation that looks like the following:
 *  g(c,z,y,x) = factor1*
 *        (c[z][y][x-2]+7*(c[z][y][x-1]+c[z][y][x])+c[z][y][x+1])
 *  similarly for g' and g"
 *  g'(c,z,y,x) = factor1*
 *        (c[z][y-2][x]+7*(c[z][y-1][x]+c[z][y][x])+c[z][y+1][x])
 *  g"(c,z,y,x) = factor1*
 *        (c[z-2][y][x]+7*(c[z-1][y][x]+c[z][y][x])+c[z+1][y][x])
 *
 *  Computing cell-centered values based on face-centered flux values
 *  h(component,z,y,x) is a stencil operation that looks like the following:
 *  h(c,z,y,x)  = factor2*
 *                  (g(c,z,y,x+1)*g(u_t,z,y,x+1)-g(c,z,y,x)*g(u_t,z,y,x))
 *  h'(c,z,y,x) = factor2*
 *                  (g'(c,z,y+1,x)*g'(v_t,z,y+1,x)-g'(c,z,y,x)*g'(v_t,z,y,x))
 *  h"(c,z,y,x) = factor2*
 *                  (g"(c,z+1,y,x)*g"(w_t,z+1,y,x)-g"(c,z,y,x)*g"(w_t,z,y,x))
 *
 *  in this example code we omit some space and time saving optimizations
 *  in order to make the code easy to learn.  FIXME: are these correct?
 *  Step 1 is to calculate all of the g() values
 *  Step 2 multiplies the values together for the first column in the
 *         equations above
 *  Step 3 Return to Step 1 for g' and then for g"
 *
 *  The following is a table describing how the notation above
 *  maps to the storage in code that we are using below
 *  value      name | variable name
 *  ----------------------------------
 *  p_{t+1}         | new_data[0]
 *  e_{t+1}         | new_data[1]
 *  u_{t+1}         | new_data[2]
 *  v_{t+1}         | new_data[3]
 *  w_{t+1}         | new_data[4]
 *  g(p_t)          | g_cache[0]
 *  g(e_t)          | g_cache[1]
 *  ... same pattern for u,v,w
 *  g'(p_t)         | g_cache[0]
 *  ... continue pattern
 *  g"(p_t)         | g_cache[0]
 *
 *  g_cache can be reused because we accumulate into new_data between
 *  iterations
 ****************************************************************************/

#define PHI_IN(c,z,y,x) *(GET_VAL_PTR(old_box,(c),(z),(y),(x)))
#define FLUXCACHEX(d,c,z,y,x) *(GET_FACE_VAL_PTR(d,gx_cache,(c),(z),(y),(x)))
#define FLUXCACHEY(d,c,z,y,x) *(GET_FACE_VAL_PTR(d,gy_cache,(c),(z),(y),(x)))
#define FLUXCACHEZ(d,c,z,y,x) *(GET_FACE_VAL_PTR(d,gz_cache,(c),(z),(y),(x)))
#define PHI_OUT(c,z,y,x) *(GET_VAL_PTR(new_box,(c),(z),(y),(x)))

/////////////////
// X-DIRECTION //
/////////////////


// This is the Flux in the X direction -- only the first portion of the flux
#define FLUX1X(c,z,y,x) {FLUXCACHEX(0,c,z,y,x)=factor1*((PHI_IN(c,z,y,(x)-2))\
                         + 7*(PHI_IN(c,z,y,(x)-1) + (PHI_IN(c,z,y,x)))\
                         + (PHI_IN(c,z,y,(x)+1)));}

// this is the second portion of the flux in the x-direction
#define FLUX2X(c,z,y,x) {FLUXCACHEX(0,c,z,y,x) *= factor2*(FLUXCACHEX(0,2,z,y,x));};

// This is the diffusion in the x-direction
#define DIFFX(c,z,y,x) {PHI_OUT(c,z,y,x) += ((FLUXCACHEX(0,c,z,y,(x)+1)) - \
                                             (FLUXCACHEX(0,c,z,y,x)));}

/////////////////
// Y-DIRECTION //
/////////////////


// This is the Flux in the Y direction -- only the first portion of the flux
#define FLUX1Y(c,z,y,x) {FLUXCACHEY(1,c,z,y,x)=factor1*((PHI_IN(c,z,(y)-2,x))\
                         + 7*(PHI_IN(c,z,(y)-1,x) + (PHI_IN(c,z,y,x)))\
                         + (PHI_IN(c,z,(y)+1,x)));}

// this is the second portion of the flux in the y-direction
#define FLUX2Y(c,z,y,x) {FLUXCACHEY(1,c,z,y,x) *= factor2*(FLUXCACHEY(1,3,z,y,x));};

// This is the diffusion in the y-direction
#define DIFFY(c,z,y,x) {PHI_OUT(c,z,y,x) += ((FLUXCACHEY(1,c,z,(y)+1,x)) - \
                                             (FLUXCACHEY(1,c,z,y,x)));}

/////////////////
// Z-DIRECTION //
/////////////////

// This is the Flux in the Z direction -- only the first portion of the flux
#define FLUX1Z(c,z,y,x) {FLUXCACHEZ(2,c,z,y,x)=factor1*((PHI_IN(c,(z)-2,y,x))\
                         + 7*(PHI_IN(c,(z)-1,y,x) + (PHI_IN(c,z,y,x)))\
                         + (PHI_IN(c,(z)+1,y,x)));}

// this is the second portion of the flux in the z-direction
#define FLUX2Z(c,z,y,x) {FLUXCACHEZ(2,c,z,y,x) *= factor2*(FLUXCACHEZ(2,4,z,y,x));};

// This is the diffusion in the z-direction
#define DIFFZ(c,z,y,x) {PHI_OUT(c,z,y,x) += ((FLUXCACHEZ(2,c,(z)+1,y,x)) - \
                                             (FLUXCACHEZ(2,c,z,y,x)));}

Real** mini_flux_div_lc(Real** old_boxes,Real** new_boxes,
                        Configuration& config,Measurements& measurements) {
    double time_spent;
    struct timeval  tv1, tv2;
    int idx,ix,iy,iz;
    int numCell= config.getInt("numCell");
    int numBox= config.getInt("numBox");
    int nGhost = NGHOST;
    int numComp= NCOMP;
    // The size of the 3D data is (numCell+2*nGhost)^3
    int full_numCell = numCell+2*nGhost;
    int full_numCell2 = full_numCell*full_numCell;
    int full_numCell3 = full_numCell*full_numCell+full_numCell;
    int totalCells = full_numCell*full_numCell*full_numCell;
    int flux_totalSize = numCell*numCell*(numCell+1);

    // allocate the g cache -- to save all of the g() calculations
    // There is one value per face in the box. (numCell+1) is the
    // number of faces in each direction.
    Real* gx_cache = NULL;
    Real* gy_cache = NULL;
    Real* gz_cache = NULL;

    // iterate over all of the boxes
    gettimeofday(&tv1, NULL);

    #pragma omp parallel for default(shared) private(idx) firstprivate(gx_cache,gy_cache,gz_cache)
    for (idx=0; idx < numBox; idx++) {
        Real* old_box = old_boxes[idx];
        Real* new_box = new_boxes[idx];

        if(gx_cache == NULL){
            gx_cache = (Real*)malloc(sizeof(Real)*numCell*numCell*(numCell+1)*numComp);
            gy_cache = (Real*)malloc(sizeof(Real)*numCell*numCell*(numCell+1)*numComp);
            gz_cache = (Real*)malloc(sizeof(Real)*numCell*numCell*(numCell+1)*numComp);
        }

#include "miniFluxdiv-cloFullStore-gen.gen"

    }

    gettimeofday(&tv2, NULL);
    double time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 +
                  (double) (tv2.tv_sec - tv1.tv_sec);
    measurements.setField("RunTime",time);
}
